from flask_wtf import FlaskForm
from wtforms import RadioField, SubmitField
from wtforms.validators import DataRequired

class DISCQuestionnaireForm(FlaskForm):
    """Formulaire pour le questionnaire DISC avec 10 questions"""
    
    q1 = RadioField(
        'Face à un problème à résoudre, vous préférez généralement :',
        choices=[
            ('D', 'Prendre rapidement une décision et passer à l\'action'),
            ('I', 'Discuter du problème avec d\'autres personnes pour trouver des solutions créatives'),
            ('S', 'Prendre le temps de réfléchir et consulter l\'avis de chacun avant de décider'),
            ('C', 'Analyser méthodiquement toutes les données disponibles avant de choisir la meilleure option')
        ],
        validators=[DataRequired()]
    )
    
    q2 = RadioField(
        'Dans une conversation, vous êtes plutôt :',
        choices=[
            ('D', 'Direct et concis, allant droit au but'),
            ('I', 'Expressif et animé, partageant facilement vos émotions'),
            ('S', 'Attentif et patient, écoutant plus que vous ne parlez'),
            ('C', 'Précis et structuré, attentif aux détails dans vos explications')
        ],
        validators=[DataRequired()]
    )
    
    q3 = RadioField(
        'Dans un projet d\'équipe, ce qui vous motive le plus c\'est :',
        choices=[
            ('D', 'Atteindre des objectifs ambitieux et obtenir des résultats concrets'),
            ('I', 'Collaborer avec les autres et créer une ambiance positive'),
            ('S', 'Contribuer à la stabilité du groupe et maintenir l\'harmonie'),
            ('C', 'Garantir la qualité du travail et respecter les normes établies')
        ],
        validators=[DataRequired()]
    )
    
    q4 = RadioField(
        'Face au changement, vous avez tendance à :',
        choices=[
            ('D', 'L\'initier vous-même et encourager les autres à suivre'),
            ('I', 'L\'accueillir avec enthousiasme et y voir de nouvelles opportunités'),
            ('S', 'Prendre le temps de vous y adapter progressivement'),
            ('C', 'L\'analyser en détail pour en comprendre tous les aspects avant de l\'accepter')
        ],
        validators=[DataRequired()]
    )
    
    q5 = RadioField(
        'Quand vous devez prendre une décision importante, vous vous basez principalement sur :',
        choices=[
            ('D', 'Votre instinct et votre capacité à obtenir des résultats rapides'),
            ('I', 'Votre intuition et l\'impact sur les personnes concernées'),
            ('S', 'Les conséquences à long terme et le maintien de la stabilité'),
            ('C', 'Les faits, les données et l\'analyse logique')
        ],
        validators=[DataRequired()]
    )
    
    q6 = RadioField(
        'Dans votre environnement de travail idéal :',
        choices=[
            ('D', 'Vous avez de l\'autonomie et des défis à relever régulièrement'),
            ('I', 'L\'ambiance est conviviale et vous pouvez interagir librement avec les autres'),
            ('S', 'L\'atmosphère est calme, prévisible et collaborative'),
            ('C', 'Tout est bien organisé, structuré et les processus sont clairement définis')
        ],
        validators=[DataRequired()]
    )
    
    q7 = RadioField(
        'Face à un conflit, vous avez tendance à :',
        choices=[
            ('D', 'L\'affronter directement pour trouver une solution rapide'),
            ('I', 'Chercher à négocier et à trouver un compromis qui satisfait tout le monde'),
            ('S', 'Éviter la confrontation et chercher à apaiser les tensions'),
            ('C', 'Analyser objectivement la situation pour identifier la solution la plus logique')
        ],
        validators=[DataRequired()]
    )
    
    q8 = RadioField(
        'Quand vous recevez une critique, vous :',
        choices=[
            ('D', 'Réagissez immédiatement et défendez votre point de vue'),
            ('I', 'Cherchez à maintenir une bonne relation malgré le désaccord'),
            ('S', 'Prenez le temps de réfléchir avant de répondre'),
            ('C', 'Demandez des précisions et des exemples concrets')
        ],
        validators=[DataRequired()]
    )
    
    q9 = RadioField(
        'Dans un projet, ce qui vous stresse le plus c\'est :',
        choices=[
            ('D', 'Le manque de progrès et les délais non respectés'),
            ('I', 'L\'absence de communication et d\'enthousiasme dans l\'équipe'),
            ('S', 'Les changements soudains et les perturbations dans la routine'),
            ('C', 'Le manque de précision et les erreurs dans le travail')
        ],
        validators=[DataRequired()]
    )
    
    q10 = RadioField(
        'Quand vous partagez une idée avec les autres, vous mettez l\'accent sur :',
        choices=[
            ('D', 'Les résultats concrets et les avantages pratiques'),
            ('I', 'L\'aspect novateur et l\'enthousiasme qu\'elle peut générer'),
            ('S', 'La façon dont elle peut bénéficier à tout le monde et maintenir l\'harmonie'),
            ('C', 'La logique, les détails et la faisabilité technique')
        ],
        validators=[DataRequired()]
    )
    
    submit = SubmitField('Voir mes résultats')
