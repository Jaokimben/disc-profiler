from flask import render_template, redirect, url_for, flash, request, session
from app.main import bp
from app.main.forms import DISCQuestionnaireForm
from app.main.disc_logic import calculate_disc_profile

@bp.route('/', methods=['GET', 'POST'])
@bp.route('/index', methods=['GET', 'POST'])
def index():
    """Page d'accueil avec introduction au test DISC"""
    return render_template('index.html', title='Évaluation du Profil DISC')

@bp.route('/questionnaire', methods=['GET', 'POST'])
def questionnaire():
    """Page du questionnaire DISC"""
    form = DISCQuestionnaireForm()
    if form.validate_on_submit():
        # Récupérer les réponses
        responses = {
            'q1': form.q1.data,
            'q2': form.q2.data,
            'q3': form.q3.data,
            'q4': form.q4.data,
            'q5': form.q5.data,
            'q6': form.q6.data,
            'q7': form.q7.data,
            'q8': form.q8.data,
            'q9': form.q9.data,
            'q10': form.q10.data
        }
        
        # Calculer le profil DISC
        disc_profile = calculate_disc_profile(responses)
        
        # Stocker les résultats dans la session
        session['disc_profile'] = disc_profile
        
        # Rediriger vers la page de résultats
        return redirect(url_for('main.results'))
    
    return render_template('questionnaire.html', title='Questionnaire DISC', form=form)

@bp.route('/results')
def results():
    """Page des résultats du profil DISC"""
    # Récupérer les résultats de la session
    disc_profile = session.get('disc_profile', None)
    
    if not disc_profile:
        flash('Veuillez d\'abord compléter le questionnaire.', 'warning')
        return redirect(url_for('main.questionnaire'))
    
    return render_template('results.html', title='Résultats du Profil DISC', profile=disc_profile)
